#!/usr/bin/env bash
# Installs PixelSmith for the current user (no sudo needed):
#   ~/.local/bin/pixelsmith
#   ~/.local/share/applications/pixelsmith.desktop   (app menu entry)
#   ~/.local/share/icons/hicolor/256x256/apps/pixelsmith.png
#
#   ./install.sh             install or update
#   ./install.sh --uninstall remove it again
set -euo pipefail

here="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
data="${XDG_DATA_HOME:-$HOME/.local/share}"
bin="$HOME/.local/bin/pixelsmith"
desktop="$data/applications/pixelsmith.desktop"
icon="$data/icons/hicolor/256x256/apps/pixelsmith.png"

refresh() {
    command -v update-desktop-database >/dev/null && update-desktop-database "$data/applications" 2>/dev/null || true
    command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -q -t "$data/icons/hicolor" 2>/dev/null || true
    # KDE Plasma keeps its own menu cache.
    for k in kbuildsycoca6 kbuildsycoca5; do
        command -v "$k" >/dev/null && { "$k" >/dev/null 2>&1 || true; break; }
    done
    return 0
}

if [[ "${1:-}" == "--uninstall" ]]; then
    rm -f "$bin" "$desktop" "$icon"
    refresh
    echo "PixelSmith removed. (Your colours in ~/.config/PixelSmith were left alone.)"
    exit 0
fi

install -Dm755 "$here/PixelSmith" "$bin"
install -Dm644 "$here/pixelsmith.png" "$icon"
mkdir -p "$(dirname "$desktop")"
# Absolute icon path: works on every desktop, no icon-theme lookup or cache involved.
sed -e "s|@EXEC@|$bin|" -e "s|@ICON@|$icon|" "$here/pixelsmith.desktop" > "$desktop"
refresh

echo "PixelSmith installed: $bin"
echo "It should now be in your applications menu."
if [[ "${XDG_CURRENT_DESKTOP:-}" == *KDE* ]]; then
    echo "KDE: if the menu shows a blank icon, run 'systemctl --user restart plasma-plasmashell' (or log out and in)."
fi
case ":$PATH:" in
    *":$HOME/.local/bin:"*) ;;
    *) echo "Note: ~/.local/bin isn't on your PATH, so 'pixelsmith' won't work from a terminal (the menu entry still does)." ;;
esac
